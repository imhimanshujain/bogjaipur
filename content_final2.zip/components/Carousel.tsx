'use client'

import { useEffect, useRef } from 'react'
import Image from 'next/image'
import { ChevronLeft, ChevronRight } from 'lucide-react'

export default function Carousel({ images }: { images: string[] }) {
  const indexRef = useRef(0)
  const intervalRef = useRef<ReturnType<typeof setInterval>>()
  const next = () => {
    indexRef.current = (indexRef.current + 1) % images.length
    const nextEl = document.getElementById('carousel-image')
    if(nextEl) nextEl.setAttribute('src', images[indexRef.current])
  }

  useEffect(() => {
    intervalRef.current = setInterval(next, 3000)
    return () => clearInterval(intervalRef.current)
  }, [])

  return (
    <div className="relative w-full h-80 overflow-hidden rounded-lg shadow-lg">
      <Image id="carousel-image" src={images[0]} alt="carousel" fill className="object-cover" />
      <button onClick={() => { clearInterval(intervalRef.current); prev(); }} className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white p-2 rounded-full shadow">
        <ChevronLeft />
      </button>
      <button onClick={() => { clearInterval(intervalRef.current); next(); }} className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white p-2 rounded-full shadow">
        <ChevronRight />
      </button>
    </div>
)
}

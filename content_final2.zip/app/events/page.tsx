'use client'
import CountUp from '@/components/CountUp'
import Link from 'next/link'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { X, ChevronLeft, ChevronRight } from 'lucide-react'
import CTAButton from '../../components/CTAButton'
import Image from 'next/image'

const events = [
  {
    title: 'Startup Success Conclave (Upcoming)',
    date: 'August 10, 2025',
    description: 'An upcoming high-energy conference featuring startup founders, ecosystem leaders, and growth experts. Secure your seat now!',
    images: [],
    upcoming: true
  },
  {
    title: 'BOG Launch Event',
    date: 'April 19, 2025',
    description: 'An energetic networking event where over 150+ entrepreneurs came together to connect, collaborate, and create new business opportunities.',
    images: [
      '/event1_1.jpeg',
      '/event1_2.jpeg',
      '/event1_3.jpeg',
      '/event1_4.jpeg',
      '/event1_5.jpeg',
    ],
  }
]

export default function EventsPage() {
  const [popupImages, setPopupImages] = useState([])
  const [activeImageIndex, setActiveImageIndex] = useState(0)

  const openLightbox = (images, index) => {
    setPopupImages(images)
    setActiveImageIndex(index)
  }

  const closeLightbox = () => {
    setPopupImages([])
    setActiveImageIndex(0)
  }

  const nextImage = () => {
    setActiveImageIndex((prev) => (prev + 1) % popupImages.length)
  }

  const prevImage = () => {
    setActiveImageIndex((prev) => (prev - 1 + popupImages.length) % popupImages.length)
  }

  return (
    <div className="bg-card min-h-screen text-softtext">
      <section className="bg-card px-6 py-20 text-center text-softtext">
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="font-bold mb-4 md:text-6xl text-4xl"
        >
          Past & Upcoming Events
        </motion.h1>
        <p className="max-w-2xl mx-auto text-lg text-softtext/80">
          Explore the highlights and upcoming opportunities to connect with the BOG community.
        </p>
      </section>
      <div className="py-10 px-6 bg-indigo-50 text-center italic text-gray-700">
        “Coming together is a beginning; keeping together is progress; working together is success.” — Henry Ford
      </div>


      <section className="bg-gray-50 px-6 py-20">
        <div className="max-w-6xl mx-auto space-y-16">
          {events.map((event, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.2 }}
              viewport={{ once: true }}
              className="bg-card p-6 rounded-xl shadow"
            >
              <div className="flex items-center justify-between mb-2">
                <motion.h2 className="font-bold text-2xl text-softtext" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>{event.title}</motion.h2>
                {event.upcoming && (
                  <span className="bg-indigo-100 text-indigo-700 text-xs font-semibold px-3 py-1 rounded-full">
                    UPCOMING
                  </span>
                )}
              </div>
              <p className="mb-4 text-sm text-softtext">{event.date}</p>
              <p className="mb-6 text-softtext">{event.description}</p>

              {event.upcoming && (
                <div className="mb-6">
                  <motion.a
                    href="https://forms.gle/your-google-form-link"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-block bg-black text-white text-sm px-6 py-3 rounded-full hover:bg-gray-800 transition" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                  >
                    Register for this Event
                  </a>
                </div>
              )}

              <div className="gap-4 grid grid-cols-1 sm:grid-cols-2">
                {(event.images.slice(0, 2)).map((url, i) => (
                  <div
                    key={i}
                    className="relative w-full h-64 cursor-pointer hover:scale-105 transition rounded-lg overflow-hidden shadow"
                    onClick={() => openLightbox(event.images, i)}
                  >
                    <Image
                      src={url}
                      alt={`Event ${index + 1} image ${i + 1}`}
                      fill
                      className="object-cover"
                    />
                  </div>
                ))}
              </div>

              {event.images.length > 2 && (
                <div className="mt-4 text-center">
                  <button
                    onClick={() => openLightbox(event.images, 0)}
                    className="inline-block bg-black text-white text-sm px-6 py-2 rounded-full hover:bg-gray-800 transition"
                  >
                    View All Photos
                  </button>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      
      {/* Stats Section */}
      <section className="py-20 bg-indigo-50 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <motion.h2 className="text-4xl font-semibold mb-6" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>Our Impact At A Glance</motion.h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <p className="text-5xl font-bold text-indigo-600">200+</p>
              <p className="text-gray-700">Events Hosted</p>
            </div>
            <div>
              <p className="text-5xl font-bold text-indigo-600">500+</p>
              <p className="text-gray-700">Members Networked</p>
            </div>
            <div>
              <p className="text-5xl font-bold text-indigo-600">50+</p>
              <p className="text-gray-700">Expert Speakers</p>
            </div>
          </div>
        </div>
        <div className="text-center mt-6">
          <Link href="/events" className="inline-flex items-center text-sm font-semibold text-gray-800 hover:underline">
            View All Events <ArrowRight className="ml-1" />
          </Link>
        </div>
      </section>
      {/* Gallery */}
      <section className="py-20 bg-white px-6">
        <div className="max-w-6xl mx-auto">
          <motion.h2 className="text-4xl font-semibold mb-6 text-center" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>Gallery</motion.h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            {[1,2,3,4].map(i => (
              <div key={i} className="h-48 bg-gray-200 relative overflow-hidden rounded-lg overflow-hidden relative">
                <Image src={`/images/placeholder${i}.jpg`} alt="Gallery" fill className="object-cover" />
              </div>
            ))}
          </div>
        </div>
        <div className="text-center mt-6">
          <Link href="/events" className="inline-flex items-center text-sm font-semibold text-gray-800 hover:underline">
            View All Events <ArrowRight className="ml-1" />
          </Link>
        </div>
      </section>

      </section>

      {popupImages.length > 0 && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center px-4 py-6">
          <div className="relative w-full max-w-3xl bg-white rounded-lg overflow-hidden shadow-xl">
            <motion.button
              onClick={closeLightbox}
              className="absolute top-4 right-4 text-gray-600 hover:text-black z-10" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
            >
              <X size={28} />
            </button>
            <div className="flex items-center justify-between px-4 py-2 sm:px-6">
              <motion.button onClick={prevImage} className="text-gray-600 hover:text-black" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <ChevronLeft size={32} />
              </button>
              <div className="relative w-full h-[75vh]">
                <Image
                  src={popupImages[activeImageIndex]}
                  alt="Full Preview"
                  fill
                  className="object-contain rounded"
                />
              </div>
              <motion.button onClick={nextImage} className="text-gray-600 hover:text-black" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <ChevronRight size={32} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

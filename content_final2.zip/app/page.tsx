'use client'
import CountUp from '@/components/CountUp'

import Image from 'next/image'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { ChevronRight, ArrowRight } from 'lucide-react'
import Carousel from '@/components/Carousel'

export default function HomePage() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative h-screen bg-gray-800 text-white flex items-center justify-center px-6">
        <Image
          src="/images/hero.jpg"
          alt="Networking hero"
          fill
          className="object-cover opacity-60"
        />
        <div className="relative z-10 text-center max-w-2xl">
          <motion.h1 className="text-5xl md:text-7xl font-bold mb-4" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>Join the Leading Business Community in Jaipur</motion.h1>
          <p className="text-lg md:text-2xl mb-8">
            Collaborate, innovate, and grow with like-minded entrepreneurs. Become a part of BOG Jaipur.
          </p>
          <Link href="/contact" className="inline-flex items-center bg-black text-white px-8 py-4 rounded-full hover:bg-gray-900 transition">
            Get Started <ArrowRight className="ml-2"/>
          </Link>
        </div>
        <div className="text-center mt-6">
          <Link href="/events" className="inline-flex items-center text-sm font-semibold text-gray-800 hover:underline">
            View All Events <ArrowRight className="ml-1" />
          </Link>
        </div>
      </section>
      <div className="py-10 px-6 bg-indigo-50 text-center italic text-gray-700">
        “Great things in business are never done by one person.” — Steve Jobs
      </div>


      {/* About Section */}
      <section className="py-[150px] bg-white text-black px-6">
        <div className="max-w-6xl mx-auto text-center">
          <motion.h2 className="text-4xl font-semibold mb-6" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>Who We Are</motion.h2>
          <p className="text-gray-700 mb-12 leading-relaxed">
            Business Owners Group Jaipur is a consortium of visionary entrepreneurs, dedicated to fostering a supportive ecosystem where businesses can thrive. From networking mixers to leadership summits, our events are crafted to inspire action and deliver real results.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 bg-gray-50 rounded-xl shadow">
              <ChevronRight className="w-8 h-8 text-indigo-600 mb-4"/>
              <h3 className="text-xl font-semibold mb-2">Network with Leaders</h3>
              <p className="text-gray-600">Connect with top business minds from Jaipur and beyond.</p>
            </div>
            <div className="p-6 bg-gray-50 rounded-xl shadow">
              <ChevronRight className="w-8 h-8 text-indigo-600 mb-4"/>
              <h3 className="text-xl font-semibold mb-2">Gain Insights</h3>
              <p className="text-gray-600">Attend workshops and panels featuring industry experts.</p>
            </div>
            <div className="p-6 bg-gray-50 rounded-xl shadow">
              <ChevronRight className="w-8 h-8 text-indigo-600 mb-4"/>
              <h3 className="text-xl font-semibold mb-2">Grow Your Business</h3>
              <p className="text-gray-600">Leverage shared experiences to scale and innovate.</p>
            </div>
          </div>
        </div>
        <div className="text-center mt-6">
          <Link href="/events" className="inline-flex items-center text-sm font-semibold text-gray-800 hover:underline">
            View All Events <ArrowRight className="ml-1" />
          </Link>
        </div>
      </section>

      {/* Carousel Section */}
      <section className="py-20 bg-gray-100">
        <div className="max-w-6xl mx-auto">
          <motion.h2 className="text-3xl font-bold mb-8 text-center" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>Event Highlights</motion.h2>
          <Carousel images={['/images/event1.jpg','/images/event2.jpg','/images/event3.jpg']} />
        </div>
        <div className="text-center mt-6">
          <Link href="/events" className="inline-flex items-center text-sm font-semibold text-gray-800 hover:underline">
            View All Events <ArrowRight className="ml-1" />
          </Link>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white px-6">
        <div className="max-w-4xl mx-auto text-center">
          <motion.h2 className="text-3xl font-semibold mb-6" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>What Our Members Say</motion.h2>
          <div className="space-y-8">
            <blockquote className="italic text-gray-700">
              “BOG Jaipur transformed my network overnight. The connections I've made are priceless.”
              <cite className="block mt-2 font-semibold">— Priya Sharma, Founder</cite>
            </blockquote>
            <blockquote className="italic text-gray-700">
              “Insightful, action-driven, and well-organized. A must for any serious entrepreneur.”
              <cite className="block mt-2 font-semibold">— Aman Verma, CEO</cite>
            </blockquote>
          </div>
        </div>
        <div className="text-center mt-6">
          <Link href="/events" className="inline-flex items-center text-sm font-semibold text-gray-800 hover:underline">
            View All Events <ArrowRight className="ml-1" />
          </Link>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-24 bg-indigo-600 text-white text-center px-6">
        <motion.h2 className="text-3xl font-bold mb-4" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>Ready to Elevate Your Business?</motion.h2>
        <p className="mb-8">Join BOG Jaipur today and start your growth journey with us.</p>
        <Link href="/contact" className="inline-flex items-center bg-black text-white px-8 py-4 rounded-full hover:bg-gray-900 transition">
          Join Now <ArrowRight className="ml-2"/>
        </Link>
      
      {/* Stats Section */}
      <section className="py-20 bg-indigo-50 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <motion.h2 className="text-4xl font-semibold mb-6" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>Our Impact At A Glance</motion.h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <p className="text-5xl font-bold text-indigo-600">200+</p>
              <p className="text-gray-700">Events Hosted</p>
            </div>
            <div>
              <p className="text-5xl font-bold text-indigo-600">500+</p>
              <p className="text-gray-700">Members Networked</p>
            </div>
            <div>
              <p className="text-5xl font-bold text-indigo-600">50+</p>
              <p className="text-gray-700">Expert Speakers</p>
            </div>
          </div>
        </div>
        <div className="text-center mt-6">
          <Link href="/events" className="inline-flex items-center text-sm font-semibold text-gray-800 hover:underline">
            View All Events <ArrowRight className="ml-1" />
          </Link>
        </div>
      </section>
      {/* Gallery */}
      <section className="py-20 bg-white px-6">
        <div className="max-w-6xl mx-auto">
          <motion.h2 className="text-4xl font-semibold mb-6 text-center" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>Gallery</motion.h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            {[1,2,3,4].map(i => (
              <div key={i} className="h-48 bg-gray-200 relative overflow-hidden rounded-lg overflow-hidden relative">
                <Image src={`/images/placeholder${i}.jpg`} alt="Gallery" fill className="object-cover" />
              </div>
            ))}
          </div>
        </div>
        <div className="text-center mt-6">
          <Link href="/events" className="inline-flex items-center text-sm font-semibold text-gray-800 hover:underline">
            View All Events <ArrowRight className="ml-1" />
          </Link>
        </div>
      </section>

      </section>
    </>
)
}

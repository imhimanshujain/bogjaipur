'use client'

import Link from 'next/link'
import { motion } from 'framer-motion'
import CTAButton from './CTAButton';

export default function Contact() {
  return (
    <section className="bg-card px-6 py-20 text-center">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        viewport={{ once: true }}
        className="max-w-3xl mx-auto"
      >
        <h2 className="font-bold mb-4 md:text-4xl text-3xl text-softtext">
          Ready to Collaborate?
        </h2>
        <p className="mb-8 text-lg text-softtext">
          Whether you’re a business owner, mentor, or growth partner — we’d love to connect with you.
        </p>

        <Link href="/contact">
          <CTAButton className="bg-accent text-primary hover:bg-accent/80 animate-pulse-scale py-3 bg-card px-8 hover:bg-card text-softtext transition rounded-lg">
            Contact Us
          </CTAButton>
        </Link>
      </motion.div>
    </section>
  )
}

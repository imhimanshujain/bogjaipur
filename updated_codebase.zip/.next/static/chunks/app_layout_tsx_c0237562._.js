(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__98887231._.css",
  "static/chunks/node_modules_e7825f8f._.js",
  "static/chunks/components_ddadf673._.js"
],
    source: "dynamic"
});
